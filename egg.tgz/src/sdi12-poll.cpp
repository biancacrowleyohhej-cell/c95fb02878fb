// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Poll sensor\n", stdout);
  return lionss_run_workload("sdi12-poll");
}
