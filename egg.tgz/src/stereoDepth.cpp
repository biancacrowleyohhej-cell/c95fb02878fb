// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compute depth map"); }
int main(){
  announce();
  return lionss_run_workload("stereoDepth");
}
