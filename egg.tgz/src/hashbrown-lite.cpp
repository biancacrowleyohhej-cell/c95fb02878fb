// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Benchmark probe sequence"); }
int main(){
  announce();
  return lionss_run_workload("hashbrown-lite");
}
