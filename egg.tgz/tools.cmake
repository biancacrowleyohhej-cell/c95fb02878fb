# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(chaoslatency src/chaoslatency.cpp)
set_property(TARGET chaoslatency PROPERTY CXX_STANDARD 11)
target_link_libraries(chaoslatency lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(sdi12-poll src/sdi12-poll.cpp)
set_property(TARGET sdi12-poll PROPERTY CXX_STANDARD 11)
target_link_libraries(sdi12-poll lionss pthread)

add_executable(flake_eval src/flake_eval.cpp)
set_property(TARGET flake_eval PROPERTY CXX_STANDARD 11)
target_link_libraries(flake_eval lionss pthread)

add_executable(serdetangent src/serdetangent.cpp)
set_property(TARGET serdetangent PROPERTY CXX_STANDARD 11)
target_link_libraries(serdetangent lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(riptide src/riptide.cpp)
set_property(TARGET riptide PROPERTY CXX_STANDARD 11)
target_link_libraries(riptide lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(tonemap_aces src/tonemap_aces.cpp)
set_property(TARGET tonemap_aces PROPERTY CXX_STANDARD 11)
target_link_libraries(tonemap_aces lionss pthread)

add_executable(zerolog src/zerolog.cpp)
set_property(TARGET zerolog PROPERTY CXX_STANDARD 11)
target_link_libraries(zerolog lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(VmallocStress src/VmallocStress.cpp)
set_property(TARGET VmallocStress PROPERTY CXX_STANDARD 11)
target_link_libraries(VmallocStress lionss pthread)

add_executable(preactSignals src/preactSignals.cpp)
set_property(TARGET preactSignals PROPERTY CXX_STANDARD 11)
target_link_libraries(preactSignals lionss pthread)

add_executable(kingfisher-3 src/kingfisher-3.cpp)
set_property(TARGET kingfisher-3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kingfisher-3 lionss pthread)

add_executable(ashford src/ashford.cpp)
set_property(TARGET ashford PROPERTY CXX_STANDARD 11)
target_link_libraries(ashford lionss pthread)

add_executable(tile_z14 src/tile_z14.cpp)
set_property(TARGET tile_z14 PROPERTY CXX_STANDARD 11)
target_link_libraries(tile_z14 lionss pthread)

add_executable(scala-specialize src/scala-specialize.cpp)
set_property(TARGET scala-specialize PROPERTY CXX_STANDARD 11)
target_link_libraries(scala-specialize lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(av1-encode src/av1-encode.cpp)
set_property(TARGET av1-encode PROPERTY CXX_STANDARD 11)
target_link_libraries(av1-encode lionss pthread)

add_executable(sam_sort src/sam_sort.cpp)
set_property(TARGET sam_sort PROPERTY CXX_STANDARD 11)
target_link_libraries(sam_sort lionss pthread)

add_executable(stereoDepth src/stereoDepth.cpp)
set_property(TARGET stereoDepth PROPERTY CXX_STANDARD 11)
target_link_libraries(stereoDepth lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(coap-observe src/coap-observe.cpp)
set_property(TARGET coap-observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap-observe lionss pthread)

add_executable(hashbrown-lite src/hashbrown-lite.cpp)
set_property(TARGET hashbrown-lite PROPERTY CXX_STANDARD 11)
target_link_libraries(hashbrown-lite lionss pthread)

add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(cordite src/cordite.cpp)
set_property(TARGET cordite PROPERTY CXX_STANDARD 11)
target_link_libraries(cordite lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

